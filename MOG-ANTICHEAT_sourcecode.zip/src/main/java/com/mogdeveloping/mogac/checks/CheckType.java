package com.mogdeveloping.mogac.checks;

public enum CheckType {
    COMBAT,
    MOVEMENT,
    WORLD,
    PACKET
}